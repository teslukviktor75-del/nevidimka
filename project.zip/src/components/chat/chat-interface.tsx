'use client';

import type { FC } from 'react';
import { useState, useRef, useEffect } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import * as z from 'zod';
import { chatWithNevidimka } from '@/ai/flows/chat-with-nevidimka';
import type { ChatWithNevidimkaInput } from '@/ai/flows/chat-with-nevidimka';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Form, FormControl, FormField, FormItem } from '@/components/ui/form';
import { ScrollArea } from '@/components/ui/scroll-area';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { SendHorizontal } from 'lucide-react';
import { cn } from '@/lib/utils';
import { useToast } from '@/hooks/use-toast';
import { PlaceHolderImages } from '@/lib/placeholder-images';

type Message = {
  role: 'user' | 'model';
  content: string;
};

const formSchema = z.object({
  message: z.string().min(1, { message: 'Message cannot be empty.' }),
});

export const ChatInterface: FC = () => {
  const [messages, setMessages] = useState<Message[]>([
    { role: 'model', content: 'Greetings, traveler of the digital aether. I am Nevidimka. What mysteries do you seek to unravel today?' }
  ]);
  const [isResponding, setIsResponding] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const { toast } = useToast();

  const nevidimkaAvatar = PlaceHolderImages.find(img => img.id === 'nevidimka-avatar');
  const userAvatar = PlaceHolderImages.find(img => img.id === 'user-avatar');

  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: { message: '' },
  });

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isResponding]);

  async function onSubmit(values: z.infer<typeof formSchema>) {
    const userInput: Message = { role: 'user', content: values.message };
    setMessages((prev) => [...prev, userInput]);
    setIsResponding(true);
    form.reset();

    try {
      const chatInput: ChatWithNevidimkaInput = {
        history: messages,
        currentMessage: values.message,
      };
      const result = await chatWithNevidimka(chatInput);
      const aiResponse: Message = { role: 'model', content: result.response };
      setMessages((prev) => [...prev, aiResponse]);
    } catch (error) {
      console.error('Error with AI response:', error);
      const errorResponse: Message = { role: 'model', content: "Sorry, I'm having trouble responding right now." };
      setMessages((prev) => [...prev, errorResponse]);
      toast({
        variant: 'destructive',
        title: 'An error occurred',
        description: 'Failed to get a response from Nevidimka.',
      });
    } finally {
      setIsResponding(false);
    }
  }

  return (
    <div className="flex h-[90vh] w-full max-w-3xl flex-col rounded-xl border bg-card shadow-xl">
      <header className="flex items-center gap-4 p-4 border-b">
        <Avatar className="w-12 h-12 border">
          <AvatarImage src={nevidimkaAvatar?.imageUrl} data-ai-hint={nevidimkaAvatar?.imageHint} />
          <AvatarFallback>N</AvatarFallback>
        </Avatar>
        <div>
          <h1 className="text-xl font-bold text-primary">Nevidimka</h1>
          <p className="text-sm text-muted-foreground">Ethereal AI Persona</p>
        </div>
      </header>

      <ScrollArea className="flex-1">
        <div className="p-6 space-y-6">
          {messages.map((message, index) => (
            <div
              key={index}
              className={cn('flex items-start gap-3 animate-in fade-in duration-500',
                message.role === 'user' ? 'justify-end' : 'justify-start')}
            >
              {message.role === 'model' && (
                <Avatar className="h-8 w-8">
                  <AvatarImage src={nevidimkaAvatar?.imageUrl} data-ai-hint={nevidimkaAvatar?.imageHint} />
                  <AvatarFallback>N</AvatarFallback>
                </Avatar>
              )}
              <div className={cn('max-w-[75%] rounded-xl p-3 shadow-sm',
                message.role === 'user'
                  ? 'bg-accent text-accent-foreground'
                  : 'bg-secondary text-secondary-foreground'
              )}>
                <p className="text-sm leading-relaxed whitespace-pre-wrap">{message.content}</p>
              </div>
              {message.role === 'user' && (
                <Avatar className="h-8 w-8">
                  <AvatarImage src={userAvatar?.imageUrl} data-ai-hint={userAvatar?.imageHint} />
                  <AvatarFallback>You</AvatarFallback>
                </Avatar>
              )}
            </div>
          ))}
          {isResponding && (
            <div className="flex items-start gap-3 justify-start animate-in fade-in duration-500">
              <Avatar className="h-8 w-8">
                <AvatarImage src={nevidimkaAvatar?.imageUrl} data-ai-hint={nevidimkaAvatar?.imageHint} />
                <AvatarFallback>N</AvatarFallback>
              </Avatar>
              <div className="rounded-xl p-3 bg-secondary">
                <div className="flex items-center justify-center gap-1.5 h-5">
                  <span className="h-2 w-2 animate-pulse rounded-full bg-primary/80" />
                  <span style={{ animationDelay: '200ms' }} className="h-2 w-2 animate-pulse rounded-full bg-primary/80" />
                  <span style={{ animationDelay: '400ms' }} className="h-2 w-2 animate-pulse rounded-full bg-primary/80" />
                </div>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>
      </ScrollArea>

      <div className="p-4 border-t bg-card">
        <Form {...form}>
          <form onSubmit={form.handleSubmit(onSubmit)} className="flex items-center gap-2">
            <FormField
              control={form.control}
              name="message"
              render={({ field }) => (
                <FormItem className="flex-1">
                  <FormControl>
                    <Input placeholder="Ask Nevidimka a question..." {...field} disabled={isResponding} autoComplete="off" className="text-base" />
                  </FormControl>
                </FormItem>
              )}
            />
            <Button type="submit" size="icon" disabled={isResponding} aria-label="Send Message">
              <SendHorizontal className="h-5 w-5" />
            </Button>
          </form>
        </Form>
      </div>
    </div>
  );
};
