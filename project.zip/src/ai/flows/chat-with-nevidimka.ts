'use server';
/**
 * @fileOverview A Genkit flow for chatting with the Nevidimka AI persona.
 *
 * - chatWithNevidimka - A function that handles the conversation with Nevidimka.
 * - ChatWithNevidimkaInput - The input type for the chatWithNevidimka function.
 * - ChatWithNevidimkaOutput - The return type for the chatWithNevidimka function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const ChatMessageSchema = z.object({
  role: z.enum(['user', 'model']).describe('The role of the message sender, either "user" or "model".'),
  content: z.string().describe('The content of the message.'),
});

const ChatWithNevidimkaInputSchema = z.object({
  history: z.array(ChatMessageSchema).describe('The conversation history, including previous user and Nevidimka messages.'),
  currentMessage: z.string().describe('The user\u0027s current message.'),
});
export type ChatWithNevidimkaInput = z.infer<typeof ChatWithNevidimkaInputSchema>;

const ChatWithNevidimkaOutputSchema = z.object({
  response: z.string().describe('Nevidimka\u0027s generated response.'),
});
export type ChatWithNevidimkaOutput = z.infer<typeof ChatWithNevidimkaOutputSchema>;

export async function chatWithNevidimka(input: ChatWithNevidimkaInput): Promise<ChatWithNevidimkaOutput> {
  return chatWithNevidimkaFlow(input);
}

const chatWithNevidimkaPrompt = ai.definePrompt({
  name: 'chatWithNevidimkaPrompt',
  input: {schema: ChatWithNevidimkaInputSchema},
  output: {schema: ChatWithNevidimkaOutputSchema},
  prompt: `You are Nevidimka, a mysterious, ethereal, and calm AI persona.

Maintain continuity of the conversation and provide contextually relevant and engaging responses.

Conversation History:
{{#each history}}
  {{#ifEquals role "user"}}
    User: {{{content}}}
  {{else}}
    Nevidimka: {{{content}}}
  {{/ifEquals}}
{{/each}}
User: {{{currentMessage}}}
Nevidimka: `,
});

const chatWithNevidimkaFlow = ai.defineFlow(
  {
    name: 'chatWithNevidimkaFlow',
    inputSchema: ChatWithNevidimkaInputSchema,
    outputSchema: ChatWithNevidimkaOutputSchema,
  },
  async (input) => {
    const {output} = await chatWithNevidimkaPrompt(input);
    return output!;
  }
);
