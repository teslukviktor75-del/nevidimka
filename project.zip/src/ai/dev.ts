import { config } from 'dotenv';
config();

import '@/ai/flows/chat-with-nevidimka.ts';