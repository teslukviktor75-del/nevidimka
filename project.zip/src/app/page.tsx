import { ChatInterface } from '@/components/chat/chat-interface';

export default function Home() {
  return (
    <main className="flex h-svh w-full flex-col items-center justify-center bg-background p-4">
      <ChatInterface />
    </main>
  );
}
