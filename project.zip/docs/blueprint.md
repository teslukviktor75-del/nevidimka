# **App Name**: Nevidimka Chat

## Core Features:

- AI Persona Engine: Utilize a generative AI tool to create and maintain the 'Nevidimka' persona, generating contextually relevant and engaging responses based on user input.
- Interactive Chat Interface: Provide a clean, intuitive chat interface where users can send messages and view Nevidimka's responses.
- User Message Input: Allow users to type and send text messages to the Nevidimka persona.
- AI Response Display: Visually present Nevidimka's generated responses in a clear and readable format within the chat window.
- Conversation Context Management: Maintain the continuity of the conversation within a session, ensuring the AI persona remembers recent dialogue for coherent responses.

## Style Guidelines:

- Primary color: An ethereal blue-purple (#C5A9E6) to evoke mystery and calm.
- Background color: A very dark, desaturated purple (#17141A) to provide depth and contrast for the primary elements, complementing the mysterious theme.
- Accent color: A vibrant, purplish-blue (#3273E6) for interactive elements and highlights, adding a subtle energetic spark.
- Body and headline font: 'Inter' (sans-serif) for a modern, neutral, and highly readable experience, ideal for chat-based interactions.
- Use minimalist, outline-based icons for chat actions to maintain a clean and unobtrusive aesthetic.
- A single-column, center-aligned layout for the chat window, providing a focused conversational experience, optimized for readability on various screen sizes.
- Subtle fade-in animations for incoming messages to enhance the sense of interaction and fluidity.